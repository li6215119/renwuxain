package com.hencoder.arch

class DataCenter {
  companion object {
    fun getData() = listOf("Hi", "Rengwuxian")
  }
}
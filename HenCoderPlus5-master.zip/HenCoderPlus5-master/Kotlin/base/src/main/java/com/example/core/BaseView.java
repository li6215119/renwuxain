package com.example.core;

public interface BaseView<T> {
    T getPresenter();
}

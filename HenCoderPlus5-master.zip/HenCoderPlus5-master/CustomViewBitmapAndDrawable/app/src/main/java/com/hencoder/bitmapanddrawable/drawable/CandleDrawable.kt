package com.hencoder.bitmapanddrawable.drawable

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.drawable.Drawable

class CandleDrawable : Drawable() {
  override fun draw(canvas: Canvas) {
    // 绘制蜡烛
    // 绘制基本信息
  }

  override fun setAlpha(alpha: Int) {
    TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
  }

  override fun getOpacity(): Int {
    TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
  }

  override fun setColorFilter(colorFilter: ColorFilter?) {
    TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
  }
}
package com.hencoder.plugin;

class HenCoderExtension {
  def name = 'rengwuxian'
}
package com.hencoder.generics;

class RealShop implements Shop {
  @Override
  public Object buy() {
    return null;
  }

  @Override
  public float refund(Object item) {
    return 0;
  }
}

package com.hencoder.generics;

interface NonGenericShop {
  Object buy();

  float refund(Object item);
}

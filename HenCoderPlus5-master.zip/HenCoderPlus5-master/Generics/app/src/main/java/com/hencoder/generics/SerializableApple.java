package com.hencoder.generics;

import com.hencoder.generics.fruit.Apple;

import java.io.Serializable;

class SerializableApple extends Apple implements Serializable {
}

package com.hencoder.generics;

class Tv implements Appliance {
}

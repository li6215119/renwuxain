package com.hencoder.generics.fruit;

public interface Fruit {
  float getWeight();
}

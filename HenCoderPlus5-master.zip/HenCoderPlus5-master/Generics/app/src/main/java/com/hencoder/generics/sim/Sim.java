package com.hencoder.generics.sim;

public interface Sim {
}

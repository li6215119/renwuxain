package com.hencoder.generics;

class HenCoderMap<K, V> {
  public void put(K key, V value) {

  }

  public V get(K key) {
    return null;
  }
}

package com.hencoder.generics.fruit;

public class Banana implements Fruit {
  @Override
  public float getWeight() {
    return 0.5f;
  }
}

package com.hencoder.generics.sim;

public class ChinaUnicom implements Sim {
}

package com.hencoder.generics.sim;

public class ChinaMobile implements Sim {
}

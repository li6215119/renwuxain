package com.hencoder.generics;

class Fridge implements Appliance {
}

package com.hencoder

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.hencoder.constraintlayout.R

class LinearActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_linear)
    }
}
